/*
ecat_actuator.c

MPLAB test project for EtherCAT actuator
*/


//#include <p33FJ128MC804.h>
//#include "NEMO3.h"


#include <devices.h>
#include "hardware.h"
#include <drv_spi.h>
#include <drv_pwmx.h>
#include <drv_m25px0.h>

#include "utypes.h"
#include "esc.h"
#include "esc_foe.h"
#include "spi.h"
#include "as1543.h"
#include <timing.h>

//#define __nop() __asm("nop")

float32 pi=3.141592654;

spi_t * spi_ec;
spi_t * spi_adc0;
spi_t * spi_adc1;
spi_t * spi_aboot;
pwmx_t * pwm_mot1;
pwmx_t * pwm_mot2;
pwmx_t * pwm_mot3;
m25px0_t * spi_code;

uint8_t * leds;
uint16_t * _IOp;
int32_t *enc[3];
uint32_t *index[3];
uint16 ADCdata0[8];
uint16 ADCdata1[8];

uint16_t *ADC_X_0;

float32 pwm_duty[3];
float32 pwm_duty_prv[3];

int16 m_dc;


uint32 m_idx;

float32 V_res = 8.05664e-04;
float32 factor_adc_1v2  =  8.05664e-04;
float32 factor_adc_1v65 =  8.05664e-04;
float32 factor_adc_5v   =  2;
float32 factor_adc_12v  =  5.6808499;
float32 factor_adc_24v  =  11;

uint16   encoder_res_motor[3] = {1024,1024,1024};
float32  reduction_motor[3] = {66, 66, 66};

#define wd_reset 100
#define ramp_rate_default 100

float32 dt = 0.01;
//float32 ramp_up = ramp_rate_default;
//float32 ramp_down = -200;

float32 ramp_rate;

typedef struct __packed__
{
                    //bit 1..7
    uint8 res:2;                 //bit 1..7
    uint8 direction_m3:1;
    uint8 direction_m2:1;
    uint8 m1_pwm_d:1;
    uint8 m1_pwm_c:1;
    uint8 direction_m1:1;
    uint8 led:1;                 //bit 0
} _GPIO_A_type;

typedef struct __packed__
{
    uint8 pwm_m1_mode1:1;        //bit 7
    uint8 pwm_m1_mode2:1;
    uint8 pwm_m2_3_mode1:1;
    uint8 pwm_m2_3_mode2:1;
    uint8 pwm_m1_reset_AB:1;
    uint8 pwm_m1_reset_CD:1;
    uint8 pwm_m2_reset_AB:1;
    uint8 pwm_m3_reset_CD:1;     //bit 0
} _GPIO_B_type;

typedef struct __packed__
{
   uint8 SP_D_SPARE_O_4:1;
   uint8 SP_D_SPARE_O_3:1;
   uint8 SP_D_SPARE_O_2:1;
   uint8 SP_D_SPARE_O_1:1;
   uint8 SP_D_SPARE_I_4:1;
   uint8 SP_D_SPARE_I_3:1;
   uint8 SP_D_SPARE_I_2:1;
   uint8 SP_D_SPARE_I_1:1;
} _GPIO_Spare_type;



_GPIO_A_type *IOp_lo;
_GPIO_B_type *IOp_hi;
_GPIO_Spare_type *IOs;

uint8_t *adc_addr;

uint32 internalsetpoint;
uint16 internalcontrol;
_ESCvar         ESCvar;
_MBX            MBX[MBXBUFFERS];
_MBXcontrol     MBXcontrol[MBXBUFFERS];
uint8           MBXrun=0;
uint16          SM2_sml,SM3_sml;
_Rbuffer        Rb, Rb_Tx;
_Wbuffer        Wb, Wb_Rx;
_App            App;
uint8           TXPDOsize,RXPDOsize;
uint8           wd_ok = 1, wd_cnt = wd_reset;
uint8           Ec_state;


//uint32 x;
uint32 enc_1_pos;


float32 swap_float(float32 f)
{
 float32union temp_f;
 uint8 u8;

 temp_f.number = f;

 u8 = temp_f.b[0];
 temp_f.b[3]=u8;
 u8 = temp_f.b[1];
 temp_f.b[1] = temp_f.b[2];
 temp_f.b[2] = u8;

 return temp_f.number;
}

void setup_SPI1(void)
{
  spi_ec = spi_open(DRV_SPI_EC);
  spi_adc0 = spi_open(DRV_SPI_ADC0);

}


float32 ramp(float32 x0, float32 x_prv)
{
  float32 y0, rate;

  rate= (x0 - x_prv) / dt;
  //rate=0;
  if (rate > ramp_rate)  {
     y0 = (dt*ramp_rate) + x_prv;
  }
  else if (rate < -ramp_rate)  {
     y0 = (dt*(-ramp_rate)) + x_prv;
  }
  else  {
     y0 = x0;
  }

  return y0;
};








void ESC_objecthandler(uint16 index, uint8 subindex)
{
  switch (index)
    {
    case 0x7000:
      switch (subindex)
        {
        case 0x01:
//          do something special with 7000:01
          break;
        case 0x02:
//          do something special with 7000:02
          break;
        }
      break;
    }
}

void TXPDO_update(void)
{
  ESC_write(SM3_sma, &Rb, TXPDOsize, &ESCvar.ALevent);
}

void RXPDO_update(void)
{
  ESC_read(SM2_sma, &Wb, RXPDOsize, &ESCvar.ALevent);
}

void DIG_process(void)
{
  uint8 i_p;

  if (Ec_state & APPSTATE_OUTPUT)
    {
      if (ESCvar.ALevent & ESCREG_ALEVENT_SM2) // SM2 trigger ?
        {
          RXPDO_update();
          //pwm_duty[0] = Wb.pwm_motor[0];
          // copy ethercat buffer to application values
          pwm_duty[0]=etohs(Wb.pwm_motor[0]);
          pwm_duty[1]=etohs(Wb.pwm_motor[1]);
          pwm_duty[2]=etohs(Wb.pwm_motor[2]);
          ramp_rate=etohs(Wb.ramp_rate);
          if (ramp_rate<=0) ramp_rate=ramp_rate_default;


          pwm_duty[0]=ramp((int16)(etohs(Wb.pwm_motor[0])), pwm_duty_prv[0]);
          pwm_duty_prv[0]=pwm_duty[0];


        }
      if (!wd_ok)
        {
          ESC_stopoutput();
          // watchdog, invalid outputs
          ESC_ALerror(ALERR_WATCHDOG);
          // goto safe-op with error bit set
          ESC_ALstatus(ESCsafeop | ESCerror);
        }
    }
  else
    {
      wd_ok = 1;
      wd_cnt = wd_reset;
    }

  if (Ec_state)
    {
      // copy application values to ethercat buffer
      // Rb.status=htoes((uint16)(x++));
      //Rb.status = htoes(*(uint8*)IOp_lo);
      Rb.status=htoes((uint16)(pwm_duty[0]));
      Rb.msg_idx=htoel(m_idx);

      for (uint8 i=0; i<3; i++)
      {
        Rb.enc_position[i] =  swap_float( (2*pi/(encoder_res_motor[i]* reduction_motor[i]))* (float32)(*enc[i]) );
      }

      uint8 q=0;

      for (uint8 i=0; i<8; i++)
      {
        *adc_addr = 0x80;            // idle -> wait
        for (uint8 r=0; r< 200; r++) __nop();

        *adc_addr = 0x00;           // wait -> read
        for (uint8 r=0; r< 200; r++) __nop();
//
        while ( (*ADC_X_0 & 0x8000) == 0);
        ADCdata0[i] = *ADC_X_0;

        for (uint8 r=0; r< 200; r++) __nop();





        delay_ns(100);
        if (i==0) i_p =7; else i_p=i-1;

        Rb.ADC[i_p]=swap_float( (float32)(((*ADC_X_0 & 0xFFFF))));
      };


      Rb.ADC[0]=swap_float( (float32)(((ADCdata0[2] & 0x0FFF))));
      Rb.ADC[1]=swap_float( (float32)(((ADCdata0[3] & 0x0FFF))));
      Rb.ADC[2]=swap_float( (float32)(((ADCdata0[4] & 0x0FFF))));
      Rb.ADC[3]=swap_float( (float32)(((ADCdata0[5] & 0x0FFF))));
      Rb.ADC[4]=swap_float( (float32)(((ADCdata0[6] & 0x0FFF))));
      Rb.ADC[5]=swap_float( (float32)(((ADCdata0[7] & 0x0FFF))));
      Rb.ADC[6]=swap_float( (float32)(((ADCdata0[0] & 0x0FFF))));
      Rb.ADC[7]=swap_float( (float32)(((ADCdata0[1] & 0x0FFF))));


     //   Rb.ADC[i]=swap_float( ((float32)(ADCdata0[i]))*V_res );

      Rb.ADC[8] =swap_float( ((float32)(ADCdata1[0]))*V_res * factor_adc_5v );
      Rb.ADC[9] =swap_float( ((float32)(ADCdata1[1]))*V_res * factor_adc_12v );
      Rb.ADC[10]=swap_float( ((float32)(ADCdata1[2]))*V_res * factor_adc_24v);
      Rb.ADC[11]=swap_float( ((float32)(ADCdata1[3])) );
      Rb.ADC[12]=swap_float( ((float32)(ADCdata1[4])) );
      Rb.ADC[13]=swap_float( ((float32)(ADCdata1[5])) );
      Rb.ADC[14]=swap_float( ((float32)(ADCdata1[6]))*V_res );
      Rb.ADC[15]=swap_float( ((float32)(ADCdata1[7]))*V_res );




      /*
      for (uint8 i=0; i<8; i++)
      {
        //Rb.ADC[i]=(float32)(htoes(ADCdata0[i]));
        //Rb.ADC[i+8]=(float32)(htoes(ADCdata1[i]));
        Rb.ADC[i]=swap_float((float32)(i));
        Rb.ADC[i+8]=swap_float((float32)(i+8));
      };
      */
      TXPDO_update();
   }
}



int main()
{

  Wb.ramp_rate=etohs(100);
  ramp_rate=100;

  IOp_lo = (void *)Base_GPIO1;
  IOp_hi = (void *)(Base_GPIO1+1);

  IOs = (void *)(Base_GPIO2+1);

  adc_addr = (void *)(Base_GPIO2);

  enc[0] = (void *)Base_WB_ENCODER_1;
  enc[1] = (void *)Base_WB_ENCODER_2;
  enc[2] = (void *)Base_WB_ENCODER_3;
  index[0] = (void *)(Base_WB_ENCODER_1 + 4);
  index[1] = (void *)(Base_WB_ENCODER_2 + 4);
  index[2] = (void *)(Base_WB_ENCODER_3 + 4);

  ADC_X_0 = (void *)(Base_WB_ADCX);
  *ADC_X_0 = 0;


  m_idx=0;

  *enc[0]=0; *index[0]=0;
  *enc[1]=0; *index[1]=0;
  *enc[2]=0; *index[2]=0;

  //IOp = (_GPIO_type *)_IOp;


  //*_IOp=0x01;


  spi_code = m25px0_open(DRV_M25PX0);



  uint16 c=0;
  uint16 u16_ADC[16];


  //uint8 d=0;

  spi_ec = spi_open(DRV_SPI_EC);
  spi_adc0 = spi_open(DRV_SPI_ADC0);
  spi_adc1 = spi_open(DRV_SPI_ADC1);
  spi_aboot = spi_open(DRV_SPI_ABOOT);

  spi_set_endianess( spi_ec, true );

  spi_set_mode( spi_ec, SPI_MODE3 );
  spi_set_baudrate( spi_ec, 10000000 );

  spi_set_endianess( spi_adc0, true );

  spi_set_mode( spi_adc0, SPI_MODE2 );
  spi_set_baudrate( spi_adc0, 10000000 );

  spi_set_endianess( spi_adc1, true );

  spi_set_mode( spi_adc1, SPI_MODE2 );
  spi_set_baudrate( spi_adc1, 10000000 );

  spi_set_mode( spi_aboot, SPI_MODE3 );
  spi_set_baudrate( spi_aboot, 1000000 );


  InitSPIADC(spi_adc0);
  InitSPIADC(spi_adc1);

  pwm_mot1 = pwmx_open(DRV_PWMX_1);
  pwm_mot2 = pwmx_open(DRV_PWMX_2);
  pwm_mot3 = pwmx_open(DRV_PWMX_3);


  pwmx_set_resolution_mode(pwm_mot1, PWMX_MODE_8BIT);
  pwmx_enable_controller(pwm_mot1);
  pwmx_set_frequency(pwm_mot1, 50000);
  pwmx_set_dutycycle(pwm_mot1, 0);

  pwmx_set_resolution_mode(pwm_mot2, PWMX_MODE_8BIT);
  pwmx_enable_controller(pwm_mot2);
  pwmx_set_frequency(pwm_mot2, 50000);
  pwmx_set_dutycycle(pwm_mot2, 0);

  pwmx_set_resolution_mode(pwm_mot3, PWMX_MODE_8BIT);
  pwmx_enable_controller(pwm_mot3);
  pwmx_set_frequency(pwm_mot3, 50000);
  pwmx_set_dutycycle(pwm_mot3, 0);


  //H-bridge motor M1
  (*IOp_hi).pwm_m1_mode1 =0; (*IOp_hi).pwm_m1_mode2 =1;     //parallel full bridge mode ( 0 1 )
  (*IOp_lo).m1_pwm_c=0     ; (*IOp_lo).m1_pwm_d=0;          //c and d not used

  (*IOp_hi).pwm_m1_reset_AB = 1; (*IOp_hi).pwm_m1_reset_CD = 1;  delay_ms(10);
  (*IOp_hi).pwm_m1_reset_AB = 0; (*IOp_hi).pwm_m1_reset_CD = 0;  delay_ms(10);
  (*IOp_hi).pwm_m1_reset_AB = 1; (*IOp_hi).pwm_m1_reset_CD = 1;  delay_ms(10);

  //H-bridge motor M2 and M3
  (*IOp_hi).pwm_m2_3_mode1 =0; (*IOp_hi).pwm_m2_3_mode2 =0;     //dual full bridge mode ( 0 0 )

  (*IOp_hi).pwm_m2_reset_AB = 1;  (*IOp_hi).pwm_m3_reset_CD = 1;  delay_ms(10);
  (*IOp_hi).pwm_m2_reset_AB = 0;  (*IOp_hi).pwm_m3_reset_CD = 0;  delay_ms(10);
  (*IOp_hi).pwm_m2_reset_AB = 1;  (*IOp_hi).pwm_m3_reset_CD = 1;  delay_ms(10);



  delay_ms(333);

  //IOp->led = 1;

  TXPDOsize = sizeTXPDO();
  RXPDOsize = sizeRXPDO();

  delay_ms(333);
  //IOp->led = 0;
  //x=0;


// wait until ESC is started up
  while ((ESCvar.DLstatus & 0x0001) == 0)
    {
        ESC_read(ESCREG_DLSTATUS, &ESCvar.DLstatus, sizeof(ESCvar.DLstatus), &ESCvar.ALevent);
        ESCvar.DLstatus = etohs(ESCvar.DLstatus);
        delay_us(10);
    }

  delay_ms(333);

// reset ESC to init state
  ESC_ALstatus(ESCinit);
  ESC_ALerror(ALERR_NONE);
  ESC_stopmbx();
  ESC_stopinput();
  ESC_stopoutput();

  delay_ms(333);
  //x=0;

  // cyclic application loop


  while(1)
  {

      ESC_read(ESCREG_LOCALTIME, &ESCvar.Time, sizeof(ESCvar.Time), &ESCvar.ALevent);
      ESCvar.Time = etohl(ESCvar.Time);

      DIG_process();

      if (ESCvar.ALevent) ESC_ALevent();
      ESC_state();
      m_idx++;

      if (ESC_mbxprocess())
        {
        ESC_coeprocess();
        ESC_foeprocess();
        //ESC_xoeprocess();
        }

      c++;
      if (c>5000) {
        c=0;
        (*IOp_lo).led = 1 - (*IOp_lo).led;
      };

//        Read8ADC(spi_adc0, &ADCdata0[0]);
        Read8ADC(spi_adc1, &ADCdata1[0]);


        //motor 1

        (*IOp_lo).direction_m1 = (pwm_duty[0] < 0);                                 //check rotation direction
        if (pwm_duty[0] >= 0) m_dc=pwm_duty[0]; else m_dc=-pwm_duty[0];              //invert dutycycle
        pwmx_set_dutycycle(pwm_mot1, (uint32_t)(m_dc));                              //set duty cycle

        //motor 2
        (*IOp_lo).direction_m2 = (pwm_duty[1] < 0);                                 //check rotation direction
        if (pwm_duty[1] >= 0) m_dc=pwm_duty[1]; else m_dc=-pwm_duty[1];              //invert dutycycle
        pwmx_set_dutycycle(pwm_mot2, (uint32_t)(m_dc));                              //set duty cycle

        //motor 3
        (*IOp_lo).direction_m3 = (pwm_duty[2] < 0);                                 //check rotation direction
        if (pwm_duty[2] >= 0) m_dc=pwm_duty[2]; else m_dc=-pwm_duty[2];              //invert dutycycle
        pwmx_set_dutycycle(pwm_mot3, (uint32_t)(m_dc));                              //set duty cycle


        //pwm_duty_prv[1]=pwm_duty[1];
        //pwm_duty_prv[2]=pwm_duty[2];


        Rb.spare_in= (*IOs).SP_D_SPARE_I_1 |
                     ((*IOs).SP_D_SPARE_I_2 << 1) |
                     ((*IOs).SP_D_SPARE_I_3 << 2) |
                     ((*IOs).SP_D_SPARE_I_4 << 3);

        Rb.spare_in = (~Rb.spare_in) & 0x0F;

        (*IOs).SP_D_SPARE_O_1 = ~(Wb.spare_out & 0x01);
        (*IOs).SP_D_SPARE_O_2 = ~((Wb.spare_out & 0x02) >> 1);
        (*IOs).SP_D_SPARE_O_3 = ~((Wb.spare_out & 0x04) >> 2);
        (*IOs).SP_D_SPARE_O_4 = ~((Wb.spare_out & 0x08) >> 3);

  }

};



