/*
 *	Software Platform Generated File
 *	--------------------------------
 */


#include "swplatform.h"

/* Global variables to access Software Platform stacks */
spi_t *    drv_spi_adc0;
spi_t *    drv_spi_adc1;
spi_t *    drv_spi_ec;
pwmx_t *   drv_pwmx_3;
pwmx_t *   drv_pwmx_1;
pwmx_t *   drv_pwmx_2;
m25px0_t * drv_m25px0;

/* Initialize all stacks in the Software Platform */
void swplatform_init_stacks(void)
{
    drv_spi_adc0 = spi_open(DRV_SPI_ADC0);
    drv_spi_adc1 = spi_open(DRV_SPI_ADC1);
    drv_spi_ec   = spi_open(DRV_SPI_EC);
    drv_pwmx_3   = pwmx_open(DRV_PWMX_3);
    drv_pwmx_1   = pwmx_open(DRV_PWMX_1);
    drv_pwmx_2   = pwmx_open(DRV_PWMX_2);
    drv_m25px0   = m25px0_open(DRV_M25PX0);
}
