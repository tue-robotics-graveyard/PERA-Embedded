/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#ifndef _SWP_SYSUTILS_CFG_H
#define _SWP_SYSUTILS_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#endif
