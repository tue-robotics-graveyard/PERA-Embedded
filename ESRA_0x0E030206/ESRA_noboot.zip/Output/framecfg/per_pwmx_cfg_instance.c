/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#include "per_pwmx_cfg_instance.h"


const per_pwmx_cfg_instance_t	per_pwmx_instance_table[3] = 
{
	{
		0xFF070000,
		-1,
	},
	{
		0xFF080000,
		-1,
	},
	{
		0xFF090000,
		-1,
	},
};

