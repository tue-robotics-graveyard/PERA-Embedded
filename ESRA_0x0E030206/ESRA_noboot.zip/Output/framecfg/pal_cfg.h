/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#ifndef _SWP_PAL_CFG_H
#define _SWP_PAL_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#define PAL_INTERRUPT_CONTROL_CFG		0x00000000

#endif
