/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#include "per_ioport_cfg_instance.h"


const per_ioport_cfg_instance_t	per_ioport_instance_table[2] = 
{
	{
		0xFF0C0000,
		PER_IOPORT_BUSWIDTH_8,
		2,
	},
	{
		0xFF0A0000,
		PER_IOPORT_BUSWIDTH_8,
		2,
	},
};

