/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#include "per_wb_interface_cfg_instance.h"


const per_wb_interface_cfg_instance_t	per_wb_interface_instance_table[4] = 
{
	{
		0xFF000000,
	},
	{
		0xFF040000,
	},
	{
		0xFF060000,
	},
	{
		0xFF050000,
	},
};

