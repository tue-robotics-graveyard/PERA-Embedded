/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#include "drv_m25px0_cfg_instance.h"


const drv_m25px0_cfg_instance_t	drv_m25px0_instance_table[1] = 
{
	{
		DRV_M25PX0_SPI_MODE_MODE3,
		10000000,
		0,
		0,
	},
};

