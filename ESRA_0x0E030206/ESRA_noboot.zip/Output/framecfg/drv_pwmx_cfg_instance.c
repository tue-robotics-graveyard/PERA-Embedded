/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#include "drv_pwmx_cfg_instance.h"


const drv_pwmx_cfg_instance_t	drv_pwmx_instance_table[3] = 
{
	{
		DRV_PWMX_RESOLUTION_8BIT,
		0,
		0,
		2,
	},
	{
		DRV_PWMX_RESOLUTION_8BIT,
		0,
		0,
		1,
	},
	{
		DRV_PWMX_RESOLUTION_8BIT,
		0,
		0,
		0,
	},
};

