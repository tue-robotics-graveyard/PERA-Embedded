/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#include "wb_interfaces.h"

//------------------------------------------------------------------------------
// WB_INTERFACE component: WB_ADCX
//------------------------------------------------------------------------------

#define WB_ADCX_DATA(base) ((volatile uint16_t *) base)

#define WB_ADCX_ADC_CHAN_0_ADDR_OFFSET 0x0

//------------------------------------------------------------------------------
// Functions for the register: ADC_CHAN_0
//------------------------------------------------------------------------------

uint16_t wb_adcx_get_adc_chan_0(
    void
)
{
    return WB_ADCX_DATA(0xFF000000)[WB_ADCX_ADC_CHAN_0_ADDR_OFFSET];
}

//------------------------------------------------------------------------------
// WB_INTERFACE component: WB_ENCODER_1
//------------------------------------------------------------------------------

#define WB_ENCODER_1_DATA(base) ((volatile uint32_t *) base)

#define WB_ENCODER_1_COUNT_ADDR_OFFSET 0x0
#define WB_ENCODER_1_INDEX_ADDR_OFFSET 0x1

//------------------------------------------------------------------------------
// Functions for the register: COUNT
//------------------------------------------------------------------------------

uint32_t wb_encoder_1_get_count(
    void
)
{
    return WB_ENCODER_1_DATA(0xFF040000)[WB_ENCODER_1_COUNT_ADDR_OFFSET];
}

//------------------------------------------------------------------------------
// Functions for the register: INDEX
//------------------------------------------------------------------------------

uint32_t wb_encoder_1_get_index(
    void
)
{
    return WB_ENCODER_1_DATA(0xFF040000)[WB_ENCODER_1_INDEX_ADDR_OFFSET];
}

//------------------------------------------------------------------------------
// WB_INTERFACE component: WB_ENCODER_2
//------------------------------------------------------------------------------

#define WB_ENCODER_2_DATA(base) ((volatile uint32_t *) base)

#define WB_ENCODER_2_COUNT_ADDR_OFFSET 0x0
#define WB_ENCODER_2_INDEX_ADDR_OFFSET 0x1

//------------------------------------------------------------------------------
// Functions for the register: COUNT
//------------------------------------------------------------------------------

uint32_t wb_encoder_2_get_count(
    void
)
{
    return WB_ENCODER_2_DATA(0xFF060000)[WB_ENCODER_2_COUNT_ADDR_OFFSET];
}

//------------------------------------------------------------------------------
// Functions for the register: INDEX
//------------------------------------------------------------------------------

uint32_t wb_encoder_2_get_index(
    void
)
{
    return WB_ENCODER_2_DATA(0xFF060000)[WB_ENCODER_2_INDEX_ADDR_OFFSET];
}

//------------------------------------------------------------------------------
// WB_INTERFACE component: WB_ENCODER_3
//------------------------------------------------------------------------------

#define WB_ENCODER_3_DATA(base) ((volatile uint32_t *) base)

#define WB_ENCODER_3_COUNT_ADDR_OFFSET 0x0
#define WB_ENCODER_3_INDEX_ADDR_OFFSET 0x1

//------------------------------------------------------------------------------
// Functions for the register: COUNT
//------------------------------------------------------------------------------

uint32_t wb_encoder_3_get_count(
    void
)
{
    return WB_ENCODER_3_DATA(0xFF050000)[WB_ENCODER_3_COUNT_ADDR_OFFSET];
}

//------------------------------------------------------------------------------
// Functions for the register: INDEX
//------------------------------------------------------------------------------

uint32_t wb_encoder_3_get_index(
    void
)
{
    return WB_ENCODER_3_DATA(0xFF050000)[WB_ENCODER_3_INDEX_ADDR_OFFSET];
}

