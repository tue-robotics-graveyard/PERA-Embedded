/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#include "per_spi_cfg_instance.h"


const per_spi_cfg_instance_t	per_spi_instance_table[4] = 
{
	{
		0xFF010000,
		32,
		0,
		0,
		0,
	},
	{
		0xFF020000,
		32,
		0,
		0,
		0,
	},
	{
		0xFF030000,
		32,
		0,
		0,
		0,
	},
	{
		0xFF0B0000,
		8,
		0,
		0,
		0,
	},
};

