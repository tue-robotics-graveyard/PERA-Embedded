/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#ifndef _SWP_DRV_SPI_CFG_H
#define _SWP_DRV_SPI_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#define DRV_SPI_INSTANCE_COUNT		4

#define DRV_SPI_MAXIMUM_NUMBER_INSTANCE_USERS		1

#endif
