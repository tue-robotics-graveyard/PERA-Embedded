/* ecat_actuator.c
*/
#include <devices.h>
#include "hardware.h"
#include <drv_spi.h>
#include <drv_pwmx.h>
#include <drv_m25px0.h>
#include "utypes.h"
#include "esc.h"
#include "esc_foe.h"
#include "spi.h"
#include "as1543.h"
#include <timing.h>

#define wd_reset 100
#define ramp_rate_default 100

typedef struct __packed__
{
    uint8 res:2;                 //bit 6..7
    uint8 direction_m3:1;
    uint8 direction_m2:1;
    uint8 m1_pwm_d:1;
    uint8 m1_pwm_c:1;
    uint8 direction_m1:1;
    uint8 led:1;                 //bit 0
} _GPIO_A_type;

typedef struct __packed__
{
    uint8 pwm_m1_mode1:1;        //bit 7
    uint8 pwm_m1_mode2:1;
    uint8 pwm_m2_3_mode1:1;
    uint8 pwm_m2_3_mode2:1;
    uint8 pwm_m1_reset_AB:1;
    uint8 pwm_m1_reset_CD:1;
    uint8 pwm_m2_reset_AB:1;
    uint8 pwm_m3_reset_CD:1;     //bit 0
} _GPIO_B_type;

typedef struct __packed__
{
   uint8 SP_D_SPARE_O_4:1;
   uint8 SP_D_SPARE_O_3:1;
   uint8 SP_D_SPARE_O_2:1;
   uint8 SP_D_SPARE_O_1:1;
   uint8 SP_D_SPARE_I_4:1;
   uint8 SP_D_SPARE_I_3:1;
   uint8 SP_D_SPARE_I_2:1;
   uint8 SP_D_SPARE_I_1:1;
} _GPIO_Spare_type;

float32 pi=3.141592654;

spi_t * spi_ec;
spi_t * spi_adc0;
spi_t * spi_adc1;
spi_t * spi_aboot;
pwmx_t * pwm_mot1;
pwmx_t * pwm_mot2;
pwmx_t * pwm_mot3;
m25px0_t * spi_code;
uint8_t * pwm_ch3;
uint8_t * leds;
uint16_t * _IOp;
int32_t *enc[3];
uint32_t *index[3];
uint16 ADCdata0[8];
uint16 ADCdata1[8];
uint16_t *ADC_X_0;
uint16_t *ADC_X_1;
float32 pwm_duty[3];
float32 pwm_temp;
float32 pwm_duty_prv[3];
int16 m_dc;
uint32 m_idx;
float32 V_res = 8.05664e-04;
float32 factor_adc_1v2  =  8.05664e-04;
float32 factor_adc_1v65 =  8.05664e-04;
float32 factor_adc_5v   =  2;
float32 factor_adc_12v  =  5.6808499;
float32 factor_adc_24v  =  11;
uint16   encoder_res_motor[3] = {1024,1024,1024};
float32  reduction_motor[3] = {66, 66, 66};
float32 dt = 0.01;
float32 f_ramp_rate=ramp_rate_default;
uint8   heart_beat;
uint8   pre_heart_beat;
uint8 adc0_channels[9]= {0,1,2,3,4,5,6,7,0};
//uint8 adc0_channels[9]= {7,7,7,7,7,7,7,7,0};
//uint8 adc1_channels[9]= {0,1,2,6,7,0,0,0,0};
uint8 adc1_channels[9]= {0,1,2,3,4,5,6,7,0};
uint32 ADC_cur[3];
uint32 heart_beat_timeout=0;
enum e_esra_state{
   E_OK,
   E_POWER_DOWN,
   E_COM_DOWN,
   E_NO_OP_STATE
}                                   esra_state=E_OK;
_GPIO_A_type *IOp_lo;
_GPIO_B_type *IOp_hi;
_GPIO_Spare_type *IOs;
uint8_t *adc_addr;
uint32 internalsetpoint;
uint16 internalcontrol;
_ESCvar         ESCvar;
_MBX            MBX[MBXBUFFERS];
_MBXcontrol     MBXcontrol[MBXBUFFERS];
uint8           MBXrun=0;
uint16          SM2_sml,SM3_sml;
_Rbuffer        Rb, Rb_Tx;
_Wbuffer        Wb, Wb_Rx;
_App            App;
uint16          TXPDOsize,RXPDOsize;
uint8           wd_ok = 1, wd_cnt = wd_reset;
uint8           Ec_state;
uint32 enc_1_pos;
int16           pwm[3];

/*
void APP_safeoutput(void)
{
}
*/
float32 swap_float(float32 f)
{
 float32union temp_f;
 uint8 u8;

 temp_f.number = f;
 u8 = temp_f.b[0];
 temp_f.b[0] = temp_f.b[3];
 temp_f.b[3]=u8;
 u8 = temp_f.b[1];
 temp_f.b[1] = temp_f.b[2];
 temp_f.b[2] = u8;
 return temp_f.number;
}

void setup_SPI1(void)
{
  spi_ec = spi_open(DRV_SPI_EC);
  spi_adc0 = spi_open(DRV_SPI_ADC0);
}

float32 ramp(float32 x0, float32 x_prv)
{
  float32 y0, rate;

  rate= (x0 - x_prv) / dt;
  //rate=0;
  if (rate > f_ramp_rate)  {
     y0 = (dt*f_ramp_rate) + x_prv;
  }
  else if (rate < -f_ramp_rate)  {
     y0 = (dt*(-f_ramp_rate)) + x_prv;
  }
  else  {
     y0 = x0;
  }
  return y0;
};

void ESC_objecthandler(uint16 index, uint8 subindex)
{
  switch (index)
    {
    case 0x7000:
      switch (subindex)
        {
        case 0x01:
//          do something special with 7000:01
          break;
        case 0x02:
//          do something special with 7000:02
          break;
        }
      break;
    }
}

void TXPDO_update(void)
{
  ESC_write(SM3_sma, (uint8*)&Rb, TXPDOsize, (uint8*)&ESCvar.ALevent);
}

void RXPDO_update(void)
{
  ESC_read(SM2_sma, (uint8*)&Wb, RXPDOsize, (uint8*)&ESCvar.ALevent);
}

void DIG_process(void)
{
  uint16 q=0;

  if (Ec_state & APPSTATE_OUTPUT)
    {
      if (ESCvar.ALevent & ESCREG_ALEVENT_SM2) // SM2 trigger ?
        {
          RXPDO_update();
        }
      if (!wd_ok)
        {
          ESC_stopoutput();
          // watchdog, invalid outputs
          ESC_ALerror(ALERR_WATCHDOG);
          // goto safe-op with error bit set
          ESC_ALstatus(ESCsafeop | ESCerror);
        }
    }
  else
    {
      wd_ok = 1;
      wd_cnt = wd_reset;
    }
  if (Ec_state)
    {
// copy application values to ethercat buffer
      // Rb.status=htoes((uint16)(x++));
      //Rb.status = htoes(*(uint8*)IOp_lo);
//      Rb.status=htoes((uint16)(pwm_duty[0]));
// Macro - separate increment
//      Rb.msg_idx=htoel(m_idx++);
      Rb.msg_idx=htoel(m_idx);
      m_idx++;
      for (uint8 i=0; i<3; i++)
      {
//        Rb.enc_position[i] =  swap_float( (2*pi/(encoder_res_motor[i]* reduction_motor[i]))* (float32)(*enc[i]) );
//        Rb.enc_position[i] = htoel(*enc[i]);
        q=(uint16)(*enc[i]);
        Rb.enc_position[i] = htoes(q);
//        Rb.enc_position[i] = htoes((uint16)((*enc[i]) & 0xFFFF));
      }
      // *****  read ADC converters  *****
      for (uint8 i=0; i<9; i++){
        *adc_addr = adc0_channels[i] | 0x80;            // idle -> wait
        *adc_addr = adc1_channels[i] | 0x80;            // idle -> wait
        for (uint8 r=0; r< 13; r++) __nop();
        *adc_addr = adc0_channels[i] & 0x7F;           // wait -> read
        *adc_addr = adc1_channels[i] & 0x7F;           // wait -> read
        if(i!=0){
          Rb.ADC[i-1]=swap_float( (float32)(((ADCdata0[i-1]))));
          switch(i)
          {
          case 1:
            Rb.ADC[8] =swap_float( ((float32)(ADCdata1[0]))*V_res * factor_adc_5v  );
            break;
          case 2:
            Rb.ADC[9] =swap_float( ((float32)(ADCdata1[1]))*V_res * factor_adc_12v );
            break;
          case 3:
            Rb.ADC[10]=swap_float( ((float32)(ADCdata1[2]))*V_res * factor_adc_24v);
            break;
          case 4:
            Rb.ADC[11]=swap_float( (float32)(ADCdata1[3]));
            break;
          case 5:
            Rb.ADC[12]=swap_float( (float32)(ADCdata1[4]));
            break;
          case 6:
            Rb.ADC[13]=swap_float( (float32)(ADCdata1[5]));
            break;
          case 7:
            Rb.ADC[14]=swap_float( ((float32)(ADCdata1[6]))*V_res);
            break;
          case 8:
            Rb.ADC[15]=swap_float( ((float32)(ADCdata1[7]))*V_res);
            break;
          }
        }
        while ( (*ADC_X_0 & 0x8000) == 0);
        if(i!=0)ADCdata0[adc0_channels[i-1]] = *ADC_X_0 & 0x0FFF;
        while ( (*ADC_X_1 & 0x8000) == 0);
        if(i!=0)ADCdata1[adc1_channels[i-1]] = *ADC_X_1 & 0x0FFF;
      };
/*
      Rb.ADC[0]=swap_float( (float32)(((ADCdata0[0]))));
      Rb.ADC[1]=swap_float( (float32)(((ADCdata0[1]))));
      Rb.ADC[2]=swap_float( (float32)(((ADCdata0[2]))));
      Rb.ADC[3]=swap_float( (float32)(((ADCdata0[3]))));
      Rb.ADC[4]=swap_float( (float32)(((ADCdata0[4]))));
      Rb.ADC[5]=swap_float( (float32)(((ADCdata0[5]))));
      Rb.ADC[6]=swap_float( (float32)(((ADCdata0[6]))));
      Rb.ADC[7]=swap_float( (float32)(((ADCdata0[7]))));
      Rb.ADC[8] =swap_float( ((float32)(ADCdata1[0]))*V_res * factor_adc_5v  );
      Rb.ADC[9] =swap_float( ((float32)(ADCdata1[1]))*V_res * factor_adc_12v );
      Rb.ADC[10]=swap_float( ((float32)(ADCdata1[2]))*V_res * factor_adc_24v);
     // Rb.ADC[11]=swap_float( ((float32)(ADCdata1[3]))*V_res);
     // Rb.ADC[12]=swap_float( ((float32)(ADCdata1[4]))*V_res);
     // Rb.ADC[13]=swap_float( ((float32)(ADCdata1[5]))*V_res);
      Rb.ADC[14]=swap_float( ((float32)(ADCdata1[6]))*V_res);
      Rb.ADC[15]=swap_float( ((float32)(ADCdata1[7]))*V_res);
*/
      TXPDO_update();
   }
}

void update_flash_led(void){
  static uint16              c;

  if(c++&0x0400)(*IOp_lo).led=~(*IOp_lo).led;
}

void update_pwm(void){
  for(uint8 i=0;i<3;i++){
    if(pwm[i]!=etohs(Wb.pwm_motor[i])){
      pwm[i]=etohs(Wb.pwm_motor[i]);
      if(pwm[i]>99)pwm[i]=99;
      else if(pwm[i]<-99)pwm[i]=-99;
    }
    pwm_duty[i]=ramp((float32)pwm[i],pwm_duty[i]);
  }
}

void update_esra_state(void)
{
  heart_beat=Wb.heart_beat;
  if(!(heart_beat&0x80)){
// Enabled
    if(pre_heart_beat!= heart_beat){
// Received hart beat
      pre_heart_beat = heart_beat;
      heart_beat_timeout = ESCvar.Time;
      Rb.status|=heart_beat;
      if(esra_state==E_COM_DOWN)esra_state=E_OK;
    }else{
      if((ESCvar.Time - heart_beat_timeout)>5000000){
// Timeout for hart beat
        if(esra_state==E_OK){
          esra_state=E_COM_DOWN;
          (*IOp_lo).led = 0;
          pwm[0]=0;
          pwm[1]=0;
          pwm[2]=0;
          pwmx_set_dutycycle(pwm_mot1,0);
          pwmx_set_dutycycle(pwm_mot2,0);
          pwmx_set_dutycycle(pwm_mot3,0);
        }
      }
    }
  }else{
// Disabled
    if(esra_state==E_COM_DOWN)esra_state=E_OK;
  }
  if(!(heart_beat&0x40)){
// Enabled
    if(ADCdata1[2] < 0x0500){
// 24V low
      if(esra_state==E_OK){
        esra_state=E_POWER_DOWN;
        (*IOp_lo).led = 0;
        pwm[0]=0;
        pwm[1]=0;
        pwm[2]=0;
        pwmx_set_dutycycle(pwm_mot1,0);
        pwmx_set_dutycycle(pwm_mot2,0);
        pwmx_set_dutycycle(pwm_mot3,0);
      }
    }else{
// 24V OK
      if(esra_state==E_POWER_DOWN)esra_state=E_OK;
    }
  }else{
// Disabled
    if(esra_state==E_POWER_DOWN)esra_state=E_OK;
  }
  if(ESCvar.ALstatus!=ESCop){
// No op state
    if(esra_state==E_OK){
      esra_state=E_NO_OP_STATE;
      (*IOp_lo).led = 0;
      pwm[0]=0;
      pwm[1]=0;
      pwm[2]=0;
      pwmx_set_dutycycle(pwm_mot1,0);
      pwmx_set_dutycycle(pwm_mot2,0);
      pwmx_set_dutycycle(pwm_mot3,0);
    }
  }else{
// Op state
    if(esra_state==E_NO_OP_STATE)esra_state=E_OK;
  }
  if(heart_beat&0x01)Rb.status=htoes((uint16)(esra_state|0x80));
  else Rb.status=htoes((uint16)(esra_state));
  switch(esra_state){
  case E_COM_DOWN:
  case E_POWER_DOWN:
  case E_NO_OP_STATE:
    break;
  case E_OK:
    update_flash_led();
    update_pwm();
    (*IOp_lo).direction_m1=(pwm_duty[0]<0);
    pwmx_set_dutycycle(pwm_mot1,(uint32_t)(abs(pwm_duty[0])));
    (*IOp_lo).direction_m2=(pwm_duty[1]<0);
    pwmx_set_dutycycle(pwm_mot2,(uint32_t)(abs(pwm_duty[1])));
    (*IOp_lo).direction_m3=(pwm_duty[2]<0);
    pwmx_set_dutycycle(pwm_mot3,(uint32_t)(abs(pwm_duty[2])));
    break;
  }
}
/*
void update_spare_io(void)
{
  Rb.spare_in= (*IOs).SP_D_SPARE_I_1 |
               ((*IOs).SP_D_SPARE_I_2 << 1) |
               ((*IOs).SP_D_SPARE_I_3 << 2) |
               ((*IOs).SP_D_SPARE_I_4 << 3);
  Rb.spare_in = (~Rb.spare_in) & 0x0F;
  (*IOs).SP_D_SPARE_O_1 = 1;
//  (*IOs).SP_D_SPARE_O_1 = toggleO1;
  if(toggleO1==0)toggleO1=1;
  else toggleO1=0;
//  toggleO1=~toggleO1;
//  (*IOs).SP_D_SPARE_O_1 = ~(Wb.spare_out & 0x01);
  (*IOs).SP_D_SPARE_O_2 = ~((Wb.spare_out & 0x02) >> 1);
  (*IOs).SP_D_SPARE_O_3 = ~((Wb.spare_out & 0x04) >> 2);
  (*IOs).SP_D_SPARE_O_4 = ~((Wb.spare_out & 0x08) >> 3);
}
*/
int main()
{
  uint8 toggleO1=0;

  IOp_lo = (void *)Base_GPIO1;
  IOp_hi = (void *)(Base_GPIO1+1);
  IOs = (void *)(Base_GPIO2+1);
  adc_addr = (void *)(Base_GPIO2);
  enc[0] = (void *)Base_WB_ENCODER_1;
  enc[1] = (void *)Base_WB_ENCODER_2;
  enc[2] = (void *)Base_WB_ENCODER_3;
  index[0] = (void *)(Base_WB_ENCODER_1 + 4);
  index[1] = (void *)(Base_WB_ENCODER_2 + 4);
  index[2] = (void *)(Base_WB_ENCODER_3 + 4);
  ADC_X_0 = (void *)(Base_WB_ADCX);
  ADC_X_1 = (void *)(Base_WB_ADCX + 2);
  pwm_ch3 = (void *)(Base_GPIO2+2);
  m_idx=0;
  *enc[0]=0; *index[0]=0;
  *enc[1]=0; *index[1]=0;
  *enc[2]=0; *index[2]=0;
  spi_code = m25px0_open(DRV_M25PX0);
  spi_ec = spi_open(DRV_SPI_EC);
  spi_adc0 = spi_open(DRV_SPI_ADC0);
  spi_adc1 = spi_open(DRV_SPI_ADC1);
  spi_aboot = spi_open(DRV_SPI_ABOOT);
  spi_set_endianess( spi_ec, true );
  spi_set_mode( spi_ec, SPI_MODE3 );
  spi_set_baudrate( spi_ec, 10000000 );
  spi_set_endianess( spi_adc0, true );
  spi_set_mode( spi_adc0, SPI_MODE2 );
  spi_set_baudrate( spi_adc0, 10000000 );
  spi_set_endianess( spi_adc1, true );
  spi_set_mode( spi_adc1, SPI_MODE2 );
  spi_set_baudrate( spi_adc1, 10000000 );
  spi_set_mode( spi_aboot, SPI_MODE3 );
  spi_set_baudrate( spi_aboot, 1000000 );
  InitSPIADC(spi_adc0);
  InitSPIADC(spi_adc1);
  pwm_mot1 = pwmx_open(DRV_PWMX_1);
  pwm_mot2 = pwmx_open(DRV_PWMX_2);
  pwm_mot3 = pwmx_open(DRV_PWMX_3);
  pwmx_set_resolution_mode(pwm_mot1, PWMX_MODE_8BIT);
  pwmx_enable_controller(pwm_mot1);
  pwmx_set_frequency(pwm_mot1, 15000);
  pwmx_set_dutycycle(pwm_mot1, 0);
  pwmx_set_resolution_mode(pwm_mot2, PWMX_MODE_8BIT);
  pwmx_enable_controller(pwm_mot2);
  pwmx_set_frequency(pwm_mot2, 15000);
  pwmx_set_dutycycle(pwm_mot2, 0);
  pwmx_set_resolution_mode(pwm_mot3, PWMX_MODE_8BIT);
  pwmx_enable_controller(pwm_mot3);
  pwmx_set_frequency(pwm_mot3, 15000);
  pwmx_set_dutycycle(pwm_mot3, 0);
//H-bridge motor M1
  (*IOp_hi).pwm_m1_mode1 =0; (*IOp_hi).pwm_m1_mode2 =1;     //parallel full bridge mode ( 0 1 )
  (*IOp_lo).m1_pwm_c=0     ; (*IOp_lo).m1_pwm_d=0;          //c and d not used
  (*IOp_hi).pwm_m1_reset_AB = 1; (*IOp_hi).pwm_m1_reset_CD = 1;  delay_ms(10);
  (*IOp_hi).pwm_m1_reset_AB = 0; (*IOp_hi).pwm_m1_reset_CD = 0;  delay_ms(10);
  (*IOp_hi).pwm_m1_reset_AB = 1; (*IOp_hi).pwm_m1_reset_CD = 1;  delay_ms(10);
//H-bridge motor M2 and M3
  (*IOp_hi).pwm_m2_3_mode1 =0; (*IOp_hi).pwm_m2_3_mode2 =0;     //dual full bridge mode ( 0 0 )
  (*IOp_hi).pwm_m2_reset_AB = 1;  (*IOp_hi).pwm_m3_reset_CD = 1;  delay_ms(10);
  (*IOp_hi).pwm_m2_reset_AB = 0;  (*IOp_hi).pwm_m3_reset_CD = 0;  delay_ms(10);
  (*IOp_hi).pwm_m2_reset_AB = 1;  (*IOp_hi).pwm_m3_reset_CD = 1;  delay_ms(10);
  delay_ms(333);
  TXPDOsize = sizeTXPDO();
  RXPDOsize = sizeRXPDO();
  delay_ms(333);
// wait until ESC is started up
  while ((ESCvar.DLstatus & 0x0001) == 0)
    {
        ESC_read(ESCREG_DLSTATUS, (uint8*)&ESCvar.DLstatus, sizeof(ESCvar.DLstatus), (uint8*)&ESCvar.ALevent);
        ESCvar.DLstatus = etohs(ESCvar.DLstatus);
        delay_us(10);
    }
  delay_ms(333);
// reset ESC to init state
  ESC_ALstatus(ESCinit);
  ESC_ALerror(ALERR_NONE);
  ESC_stopmbx();
  ESC_stopinput();
  ESC_stopoutput();
  delay_ms(333);
// cyclic application loop
  pwm_duty[0]=0;
  pwm_duty[1]=0;
  pwm_duty[2]=0;
  ESC_read(0x0012, (uint8*)&(Rb.actuator_id), sizeof(Rb.actuator_id), (uint8*)&ESCvar.ALevent);
  delay_ms(60);
  while(1)
  {
// *****  Ethercat arbitration  ******
      ESC_read(ESCREG_LOCALTIME, (uint8*)&ESCvar.Time, sizeof(ESCvar.Time), (uint8*)&ESCvar.ALevent);
      ESCvar.Time = etohl(ESCvar.Time);
      DIG_process();
      if (ESCvar.ALevent) ESC_ALevent();
      ESC_state();
      if (ESC_mbxprocess())
      {
        ESC_coeprocess();
        ESC_foeprocess();
      }
// *****  User code  *****
      update_esra_state();
//      update_spare_io();
      Rb.spare_in= (*IOs).SP_D_SPARE_I_1 |
                   ((*IOs).SP_D_SPARE_I_2 << 1) |
                   ((*IOs).SP_D_SPARE_I_3 << 2) |
                   ((*IOs).SP_D_SPARE_I_4 << 3);
      Rb.spare_in = (~Rb.spare_in) & 0x0F;
//      (*IOs).SP_D_SPARE_O_1 = 1;
      (*IOs).SP_D_SPARE_O_1 = toggleO1;
//      if(test==0)test=1;
//      else test=0;
      toggleO1=~toggleO1;
    //  (*IOs).SP_D_SPARE_O_1 = ~(Wb.spare_out & 0x01);
      (*IOs).SP_D_SPARE_O_2 = ~((Wb.spare_out & 0x02) >> 1);
      (*IOs).SP_D_SPARE_O_3 = ~((Wb.spare_out & 0x04) >> 2);
      (*IOs).SP_D_SPARE_O_4 = ~((Wb.spare_out & 0x08) >> 3);
   }
};



