/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#ifndef _SWP_DRV_M25PX0_CFG_H
#define _SWP_DRV_M25PX0_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#include <drv_spi.h>

#define DRV_M25PX0_INSTANCE_COUNT		1

#define DRV_M25PX0_MAXIMUM_NUMBER_INSTANCE_USERS		0

#endif
