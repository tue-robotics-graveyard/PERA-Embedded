/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#include "drv_spi_cfg_instance.h"


const drv_spi_cfg_instance_t	drv_spi_instance_table[4] = 
{
	{
		DRV_SPI_SPIMODE_MODE3,
		2500000,
		0,
		22,
		3,
	},
	{
		DRV_SPI_SPIMODE_MODE0,
		2500000,
		1,
		22,
		1,
	},
	{
		DRV_SPI_SPIMODE_MODE0,
		2500000,
		1,
		22,
		2,
	},
	{
		DRV_SPI_SPIMODE_MODE0,
		2500000,
		1,
		22,
		0,
	},
};

