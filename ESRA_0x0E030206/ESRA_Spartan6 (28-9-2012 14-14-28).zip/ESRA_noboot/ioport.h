/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#ifndef _SWP_IOPORT_H
#define _SWP_IOPORT_H



/* Identifiers for the signals of WB_PRTIO GPIO1.
   Use the ioport_get_value() and ioport_set_value() function to 
   read and write values from/to these signals. */
#define GPIO1_PA 0                                                              // read/write
#define GPIO1_PB 1                                                              // read/write


/* Identifiers for the signals of WB_PRTIO GPIO2.
   Use the ioport_get_value() and ioport_set_value() function to 
   read and write values from/to these signals. */
#define GPIO2_PA 0                                                              // read/write
#define GPIO2_PB 1                                                              // read/write

#endif
