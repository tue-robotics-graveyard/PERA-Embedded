/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#ifndef _SWP_GENERIC_DEVICES_H
#define _SWP_GENERIC_DEVICES_H

/* application macro definitions  */
#define WB_INTERFACE_WB_ENCODER_1_BASEADDRESS		0xFF040000

#define WB_INTERFACE_WB_ENCODER_3_BASEADDRESS		0xFF050000

#define WB_INTERFACE_WB_ENCODER_2_BASEADDRESS		0xFF060000

#endif
