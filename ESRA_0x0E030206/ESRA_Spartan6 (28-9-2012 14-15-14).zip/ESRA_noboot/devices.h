/*
 *	Software Platform Generated File
 *	--------------------------------
 */

#ifndef _SWP_DEVICES_H
#define _SWP_DEVICES_H


/* instance id macros */
#define DRV_M25PX0		0
#define DRV_PWMX_1		0
#define DRV_PWMX_2		1
#define DRV_PWMX_3		2
#define DRV_SPI_ABOOT		0
#define DRV_SPI_ADC0		1
#define DRV_SPI_ADC1		2
#define DRV_SPI_EC		3
#define WB_INTERFACE_WB_ENCODER_1		0
#define WB_INTERFACE_WB_ENCODER_3		1
#define WB_INTERFACE_WB_ENCODER_2		2
#define GENERIC_DEVICES_2		3
#define GPIO1		0
#define GPIO2		1
#define WB_PWMX_3		0
#define WB_PWMX_2		1
#define WB_PWMX_1		2
#define SPI_EC		0
#define SPI_ADC0		1
#define SPI_ADC1		2
#define SPI_ABOOTLOADER		3
#define WB_ADCX		0
#define WB_ENCODER_1		1
#define WB_ENCODER_2		2
#define WB_ENCODER_3		3

/* peripheral base address and interrupt macros */
#define WB_INTERFACE_WB_ENCODER_1_BASE_ADDRESS		0xFF040000
#define WB_INTERFACE_WB_ENCODER_3_BASE_ADDRESS		0xFF050000
#define WB_INTERFACE_WB_ENCODER_2_BASE_ADDRESS		0xFF060000
#define GENERIC_DEVICES_2_BASE_ADDRESS		0
#define GPIO1_BASE_ADDRESS		0xFF0C0000
#define GPIO2_BASE_ADDRESS		0xFF0A0000
#define WB_PWMX_3_BASE_ADDRESS		0xFF070000
#define WB_PWMX_2_BASE_ADDRESS		0xFF080000
#define WB_PWMX_1_BASE_ADDRESS		0xFF090000
#define SPI_EC_BASE_ADDRESS		0xFF010000
#define SPI_ADC0_BASE_ADDRESS		0xFF020000
#define SPI_ADC1_BASE_ADDRESS		0xFF030000
#define SPI_ABOOTLOADER_BASE_ADDRESS		0xFF0B0000
#define WB_ADCX_BASE_ADDRESS		0xFF000000
#define WB_ENCODER_1_BASE_ADDRESS		0xFF040000
#define WB_ENCODER_2_BASE_ADDRESS		0xFF060000
#define WB_ENCODER_3_BASE_ADDRESS		0xFF050000
#endif
